BULK INSERT dbo.District FROM 'C:\Users\adams\Desktop\Studia moje\Semestr 4\DATA WAREHOUSES\DataAndSnapshots\Snapshots\First Time Stamp\Bulk\District.bulk' 
WITH (FIELDTERMINATOR = ',');

INSERT INTO dbo.KindergartenType VALUES
('public'),
('private'),
('language-focused'),
('Montessori-style'),
('religious-based');

BULK INSERT dbo.Facility FROM 'C:\Users\adams\Desktop\Studia moje\Semestr 4\DATA WAREHOUSES\DataAndSnapshots\Snapshots\First Time Stamp\Bulk\Facility.bulk' 
WITH (FIELDTERMINATOR = ',');

BULK INSERT dbo.Kindergarten FROM 'C:\Users\adams\Desktop\Studia moje\Semestr 4\DATA WAREHOUSES\DataAndSnapshots\Snapshots\First Time Stamp\Bulk\Kindergarten.bulk' 
WITH (FIELDTERMINATOR = ';');

BULK INSERT dbo.KindergartenFacility FROM 'C:\Users\adams\Desktop\Studia moje\Semestr 4\DATA WAREHOUSES\DataAndSnapshots\Snapshots\First Time Stamp\Bulk\KindergartenFacility.bulk' 
WITH (FIELDTERMINATOR = ',');

BULK INSERT dbo.CareType FROM 'C:\Users\adams\Desktop\Studia moje\Semestr 4\DATA WAREHOUSES\DataAndSnapshots\Snapshots\First Time Stamp\Bulk\CareType.bulk' 
WITH (FIELDTERMINATOR = '|');

BULK INSERT dbo.KindergartenCareType FROM 'C:\Users\adams\Desktop\Studia moje\Semestr 4\DATA WAREHOUSES\DataAndSnapshots\Snapshots\First Time Stamp\Bulk\KindergartenCareType.bulk' 
WITH (FIELDTERMINATOR = '|');

BULK INSERT dbo.Submission FROM 'C:\Users\adams\Desktop\Studia moje\Semestr 4\DATA WAREHOUSES\DataAndSnapshots\Snapshots\First Time Stamp\Bulk\Submission.bulk' 
WITH (FIELDTERMINATOR = '|');