Use Kindergarten
go
CREATE VIEW "KindergartenExt" AS 
SELECT 
"K"."KindergartenID", "D"."City", "D"."Name", "C"."TeachersNumber", "C"."AdditionalStaffNumber", 
"F"."FacilityNumber", "C"."SpecialNeedsAvailable"
FROM 
"Kindergarten"."dbo"."Kindergarten" AS "K", 
"Kernel"."dbo"."mytable" AS "C",
"Kindergarten"."dbo"."District" AS "D",
(SELECT "FF"."KindergartenID", COUNT("FF"."FacilityID") AS "FacilityNumber" FROM "Kindergarten"."dbo"."KindergartenFacility" AS "FF" GROUP BY "FF"."KindergartenID") AS "F"
WHERE "C"."KindergartenID" = "K"."KindergartenID"
AND "K"."DistrictID" = "D"."DistrictID"
AND "K"."KindergartenID" = "F"."KindergartenID"

DROP VIEW IF EXISTS KindergartenExt;

SELECT * FROM KindergartenExt;