--origin
USE Kernel
go
MERGE INTO FactSubmission as TargetTable
	USING SourceTable
		ON "SourceTable"."IDKindergarten" = "TargetTable"."IDKindergarten"
    AND "SourceTable"."IDCareType" = "TargetTable"."IDCareType"
    AND "SourceTable"."IDAgeGroup" = "TargetTable"."IDAgeGroup"
    AND "SourceTable"."IDYear" = "TargetTable"."IDYear"
    AND "SourceTable"."IDMiscelaneous" = "TargetTable"."IDMiscelaneous"
    AND "SourceTable"."ChildID" = "TargetTable"."ChildID"
			WHEN Not Matched by Target
				THEN -- The ID Source is not found in the Target
					INSERT
					Values (IDKindergarten, IDCareType, IDAgeGroup, IDYear, IDMiscelaneous, ChildID, PriceAge, PriceCare);