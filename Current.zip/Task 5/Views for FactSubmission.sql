DELETE FROM "Kernel"."dbo"."FactSubmission";
INSERT INTO "Kernel"."dbo"."FactSubmission" ("IDKindergarten", "IDCareType", "IDAgeGroup", "IDYear", "IDMiscelaneous", "ChildID", "PriceAge", "PriceCare") values (-1,-1,-1,-1,-1,-1,0,0)
 use Kernel
 GO
create view SourceTable1 as
SELECT "D2"."IDCareType" AS IDCareType, "D3"."IDAgeGroup" AS IDAgeGroup, "D4"."IDYear" AS IDYear, "D5"."IDMiscelaneous" AS IDMiscelaneous, "F"."SubmissionID" AS "ChildID", "F"."PriceAge" AS PriceAge, "F"."PriceCare" AS PriceCare
FROM "Kindergarten"."dbo"."Facts" AS "F" INNER
JOIN "Kernel"."dbo"."DimCareType" AS "D2" ON "F"."CareType" = "D2"."CareType" AND "F"."PriceCareGroup" = "D2"."PriceCareType"
JOIN "Kernel"."dbo"."DimAgeGroup" AS "D3" ON "F"."AgeGroup" = "D3"."AgeGroupType" AND "F"."CapacityRange" = "D3"."CapacityPerGroup" AND "F"."PriceAgeRange" = "D3"."PriceAgeGroup"
JOIN "Kernel"."dbo"."DimYear" AS "D4" ON "F"."Year" = "D4"."Year"
JOIN "Kernel"."dbo"."DimMiscelaneous" AS "D5" ON "F"."Status" = "D5"."Status" AND "F"."SpecialNeeds" = "D5"."SpecialNeeds"

create view SourceTable2 as  
Select KindergartenID, s.SubmissionID AS ChildID, 
CASE
WHEN p.IsCurrent = 0 then (Select IDKindergarten from DimKindergarten WHERE IsCurrent = 1)
WHEN p.IsCurrent = 1 then KindergartenID
END as IDKindergarten
from Kindergarten.dbo.KindergartenCareType as k
Join Kindergarten.dbo.Submission as s
ON k.KindergartenCareTypeID = s.KindergartenCareTypeID
JOIN Kernel.dbo.DimKindergarten p
ON k.KindergartenID = p.BKKindergarten

create view SourceTable as
SELECT DISTINCT d.IDKindergarten as IDKindergarten, p.IDCareType, p.IDAgeGroup, p.IDYear, p.IDMiscelaneous, p.ChildID, p.PriceAge, p.PriceCare 
FROM SourceTable2 as d
JOIN SourceTable1 as p
ON d.ChildID = p.ChildID

drop view SourceTable;
drop view SourceTable1;
DROP VIEW SourceTable2