CREATE TABLE mytable(
   KindergartenID        INTEGER  NOT NULL PRIMARY KEY 
  ,CapacityInfant        INTEGER  NOT NULL
  ,CapacityToddler       INTEGER  NOT NULL
  ,CapacityPreschooler   INTEGER  NOT NULL
  ,CapacityTotal         INTEGER  NOT NULL
  ,TeachersNumber        INTEGER  NOT NULL
  ,AdditionalStaffNumber INTEGER  NOT NULL
  ,SpecialNeedsAvailable BIT  NOT NULL
  ,PriceInfant           INTEGER  NOT NULL
  ,PriceToddler          INTEGER  NOT NULL
  ,PricePreschooler      INTEGER  NOT NULL
  ,PriceSpecialNeeds     INTEGER  NOT NULL
);
drop table mytable