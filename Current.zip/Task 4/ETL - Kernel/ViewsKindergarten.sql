Use Kernel
go

create view location as
SELECT k.KindergartenID AS BKKindergarten, d.City, d.Name AS District from Kindergarten.dbo.Kindergarten AS k
JOIN Kindergarten.dbo.District AS d
ON d.DistrictID = k.DistrictID
create view numbers as 

SELECT KindergartenID AS BKKindergarten, 
CASE 
	WHEN TeachersNumber BETWEEN 10 AND 12 THEN 'from 10 to 12'
	WHEN TeachersNumber BETWEEN 13 AND 14 THEN 'from 13 to 14'
	WHEN TeachersNumber BETWEEN 15 AND 17 THEN 'from 15 to 17'
END as NumberOfTeachers, 
CASE 
	WHEN AdditionalStaffNumber BETWEEN 1 AND 4  THEN 'from 1 to 4'
	WHEN AdditionalStaffNumber BETWEEN 5 AND 8 THEN 'from 5 to 8'
	WHEN AdditionalStaffNumber BETWEEN 9 AND 12 THEN 'from 9 to 12'
	WHEN AdditionalStaffNumber BETWEEN 13 AND 15 THEN 'from 13 to 15'
END as NumberOfAdditionalEmployees, 
CASE 
	WHEN TeachersNumber + AdditionalStaffNumber BETWEEN 11 AND 17  THEN 'from 11 to 17'
	WHEN TeachersNumber + AdditionalStaffNumber BETWEEN 18 AND 25 THEN 'from 18 to 25'
	WHEN TeachersNumber + AdditionalStaffNumber BETWEEN 26 AND 32 THEN 'from 25 to 32'
END as TotalNumberOfEmployees,
CASE 
	WHEN SpecialNeedsAvailable = 1  THEN 'HandlesSpecialNeeds'
	WHEN SpecialNeedsAvailable = 0 THEN 'DoesNotHandleSpecialNeeds'
END as HandlesSpecialNeeds  from mytable

create view facilities as
SELECT k.KindergartenID AS BKKindergarten, CASE 
	WHEN COUNT(FacilityID) BETWEEN 0 AND 4 THEN 'from 0 to 4'
	WHEN COUNT(FacilityID) BETWEEN 5 AND 9 THEN 'from 5�to 9'
	WHEN COUNT(FacilityID) BETWEEN 10 AND 15 THEN 'from 10 to 15'
END as NumberOfFacilities FROM Kindergarten.dbo.Kindergarten as k
JOIN Kindergarten.dbo.KindergartenFacility as f
ON k.KindergartenID = f.KindergartenID
GROUP BY k.KindergartenID

create view Kindergarten as
select numbers.BKKindergarten as BKKindergarten, City, District, NumberOfTeachers, NumberOfAdditionalEmployees, TotalNumberOfEmployees, NumberOfFacilities, HandlesSpecialNeeds, 1 as isCurrent, getDate() as InsertTime, '1753-01-01 00:00:00.000' as ModificationTime from location
join numbers
on location.BKKindergarten = numbers.BKKindergarten
join facilities
on facilities.BKKindergarten = location.BKKindergarten