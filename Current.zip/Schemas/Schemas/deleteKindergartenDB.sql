DROP TABLE IF EXISTS "Submission";
DROP TABLE IF EXISTS "KindergartenCareType";
DROP TABLE IF EXISTS "CareType";
DROP TABLE IF EXISTS "KindergartenFacility";
DROP TABLE IF EXISTS "Facility";
DROP TABLE IF EXISTS "Kindergarten";
DROP TABLE IF EXISTS "District";
DROP TABLE IF EXISTS "KindergartenType";