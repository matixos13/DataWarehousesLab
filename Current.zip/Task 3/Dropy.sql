use Kernel
go
drop table FactSubmission;
drop table DimAgeGroup;
drop table DimCareType;
drop table DimKindergarten;
drop table DimMiscelaneous;
drop table DimYear;