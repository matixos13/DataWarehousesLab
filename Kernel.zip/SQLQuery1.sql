USE bookstoreDW
GO
sp_changedbowner 'DESKTOP-R8H9ULC\adams'