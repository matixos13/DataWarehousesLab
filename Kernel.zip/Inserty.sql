INSERT INTO dbo.DimYear VALUES
(2002)
INSERT INTO dbo.DimAgeGroup VALUES
('infant', 'from 1 to 63', 'from 200 to 400'),
('toddler', 'from 1 to 63', 'from 200 to 400');
INSERT INTO dbo.DimMiscelaneous VALUES
('accepted', 'notspecialneeds')
INSERT INTO dbo.DimCareType VALUES
('from 500 to 1000', 'full-day')
INSERT INTO dbo.DimKindergarten VALUES
(1, 'Gdansk', 'Morena', 'from 10 to 12', 'from 1 to 4', 'from 11 to 17', 'from 0 to 4', 'DoesNotHandleSpecialNeeds')
INSERT INTO dbo.FactSubmission VALUES
(1, 1, 1, 1, 1, 1, 200, 500),
(1, 1, 2, 1, 1, 2, 300, 600),
(1, 1, 2, 1, 1, 3, 350, 500)