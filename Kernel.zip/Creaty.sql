CREATE DATABASE Kernel;

CREATE TABLE [DimKindergarten] (
  [IDKindergarten]  INT IDENTITY(1,1) PRIMARY KEY,
  [BKKindergarten] INT,
  [City] Varchar(MAX),
  [District] Varchar(MAX),
  [NumberOfTeachers] Varchar(13) CHECK (NumberOfTeachers IN ('from 10 to 12', 'from 13 to 14', 'from 15 to 17')),
  [NumberOfAdditionalEmployees] Varchar(13) CHECK (NumberOfAdditionalEmployees IN ('from 1 to 4', 'from 5 to 8', 'from 9 to 12', 'from 13 to 15')),
  [TotalNumberOfEmployees] Varchar(13) CHECK (TotalNumberOfEmployees IN ('from 11 to 17', 'from 18 to 25', 'from 25 to 32')),
  [NumberOfFacilities] Varchar(13) CHECK (NumberOfFacilities IN ('from 0 to 4', 'from 5�to 9', 'from 10 to 15')), 
  [HandlesSpecialNeeds] Varchar(25) CHECK (HandlesSpecialNeeds IN ('HandlesSpecialNeeds','DoesNotHandleSpecialNeeds'))
);

CREATE TABLE [DimCareType] (
  [IDCareType] INT IDENTITY(1,1) PRIMARY KEY,
  [PriceCareType] Varchar(17) CHECK (PriceCareType IN ('from 500 to 1000', 'from 1001 to 2000', 'from 2001 to 3000', 'from 3001 to 4000', 'from 4001 to 5000', 'from 5001 to 6000')),
  [CareType] Varchar(11) CHECK (CareType IN ('full-day', 'half-day', 'after-hours', 'summer-camp'))
);

CREATE TABLE [DimMiscelaneous] (
  [IDMiscelaneous] INT IDENTITY(1,1) PRIMARY KEY,
  [Status] Varchar(8) CHECK (Status IN ('pending', 'rejected', 'accepted', 'resigned')),
  [SpecialNeeds] Varchar(15) CHECK (SpecialNeeds IN ('special', 'notspecialneeds'))
);

CREATE TABLE [DimYear] (
  [IDYear] INT IDENTITY(1,1) PRIMARY KEY,
  [Year] INT 
);

CREATE TABLE [DimAgeGroup] (
  [IDAgeGroup] INT IDENTITY(1,1) PRIMARY KEY,
  [AgeGroupType] Varchar(12) CHECK (AgeGroupType IN('infant', 'toddler', 'preschooler')),
  [CapacityPerGroup] Varchar(15) CHECK (CapacityPerGroup IN ('from 1 to 63', 'from 64 to 80', 'from 81 to 100', 'from 100 to 120')),
  [PriceAgeGroup] Varchar(16) CHECK (PriceAgeGroup IN ('from 200 to 400', 'from 401 to 600', 'from 601 to 800', 'from 801 to 1000'))
);

CREATE TABLE [FactSubmission] (
  [IDKindergarten] INT FOREIGN KEY REFERENCES DimKindergarten,
  [IDCareType] INT FOREIGN KEY REFERENCES DimCareType,
  [IDAgeGroup] INT FOREIGN KEY REFERENCES DimAgeGroup,
  [IDYear] INT FOREIGN KEY REFERENCES DimYear,
  [IDMiscelaneous] INT FOREIGN KEY REFERENCES DimMiscelaneous,
  [ChildID] INT,
  [PriceAge] Money,
  [PriceCare] Money,
  PRIMARY KEY (IDKindergarten, IDCareType, IDAgeGroup, IDYear, IDMiscelaneous, ChildID)
);
