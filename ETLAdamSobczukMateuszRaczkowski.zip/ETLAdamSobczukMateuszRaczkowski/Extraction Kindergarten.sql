USE Kernel
go
MERGE INTO DimKindergarten as TargetTable
	USING Kindergarten as SourceTable
		ON TargetTable.BKKindergarten = SourceTable.BKKindergarten
			WHEN Not Matched 
				THEN -- The ID Source is not found in the Target
					INSERT
					Values (BKKindergarten, City, District, NumberOfTeachers, NumberOfAdditionalEmployees, TotalNumberOfEmployees, NumberOfFacilities, HandlesSpecialNeeds, isCurrent, InsertTime, ModificationTime)
			WHEN Matched --When the ID's of the row currently being looked at match but the HandlesSpecialNeeds does not match
				 AND (SourceTable.HandlesSpecialNeeds <> TargetTable.HandlesSpecialNeeds)
			THEN
				UPDATE -- change the data in the targetTable
				SET TargetTable.isCurrent = 0, TargetTable.ModificationTime = getDate()
			WHEN Not Matched By Source
			Then 
				Update
				SET TargetTable.isCurrent = 0, TargetTable.ModificationTime = getDate() ;



INSERT INTO DimKindergarten ([BKKindergarten], [City], [District], [NumberOfTeachers], [NumberOfAdditionalEmployees], [TotalNumberOfEmployees], [NumberOfFacilities], [HandlesSpecialNeeds], [isCurrent], [InsertTime], [ModificationTime]) 
select [BKKindergarten], CAST ([City] as varchar), CAST ([District] as varchar), [NumberOfTeachers], [NumberOfAdditionalEmployees], [TotalNumberOfEmployees], [NumberOfFacilities], [HandlesSpecialNeeds], '1', getDate(), [ModificationTime] from Kindergarten
except 
select [BKKindergarten], [City], [District], [NumberOfTeachers], [NumberOfAdditionalEmployees], [TotalNumberOfEmployees], [NumberOfFacilities], [HandlesSpecialNeeds], '1', getDate(), [ModificationTime] from DimKindergarten