use Kernel
go

set identity_insert DimKindergarten on
insert into DimKindergarten ([IDKindergarten], [BKKindergarten], [City], [District], [NumberOfTeachers], 
[NumberOfAdditionalEmployees], [TotalNumberOfEmployees], [NumberOfFacilities], [HandlesSpecialNeeds]) values
(-1, -1, 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown');
set identity_insert DimKindergarten off

set identity_insert DimCareType on
insert into DimCareType ([IDCareType], [PriceCareType], [CareType]) values
(-1, 'unknown', 'unknown')
set identity_insert DimCareType off

set identity_insert DimMiscelaneous on
insert into DimMiscelaneous ([IDMiscelaneous], [Status], [SpecialNeeds]) values
(-1, 'unknown', 'unknown')
set identity_insert DimMiscelaneous off

set identity_insert DimYear on
insert into DimYear ([IDYear], [Year]) values
(-1, 0000)
set identity_insert DimYear off

set identity_insert DimAgeGroup on
insert into DimAgeGroup ([IDAgeGroup], [AgeGroupType], [CapacityPerGroup], [PriceAgeGroup]) values
(-1, 'unknown', 'unknown', 'unknown')
set identity_insert DimAgeGroup off

insert into FactSubmission ([IDKindergarten], [IDCareType], [IDAgeGroup], [IDYear], [IDMiscelaneous], [ChildID], [PriceAge], [PriceCare]) values
(-1, -1, -1, -1, -1, -1, 0, 0)