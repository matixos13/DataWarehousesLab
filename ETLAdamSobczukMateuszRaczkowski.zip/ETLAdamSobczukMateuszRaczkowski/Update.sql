SELECT Count(*) from FactSubmission
SELECT * FROM DimAgeGroup