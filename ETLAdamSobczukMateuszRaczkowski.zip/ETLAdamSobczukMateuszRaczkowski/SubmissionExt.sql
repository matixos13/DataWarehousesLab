--3
use Kindergarten
go
CREATE VIEW "Facts" AS
SELECT
--SUBMISSION ID
"S"."SubmissionID",
--DIM 2
"CT"."Name" AS "CareType",
CASE
	WHEN "C"."Price" BETWEEN 500 AND 1000 THEN 'from 500 to 1000'
	WHEN "C"."Price" BETWEEN 1001 AND 2000 THEN 'from 1001 to 2000'
	WHEN "C"."Price" BETWEEN 2001 AND 3000 THEN 'from 2001 to 3000'
	WHEN "C"."Price" BETWEEN 3001 AND 4000 THEN 'from 3001 to 4000'
	WHEN "C"."Price" BETWEEN 4001 AND 5000 THEN 'from 4001 to 5000'
	WHEN "C"."Price" BETWEEN 5001 AND 6000 THEN 'from 5001 to 6000'
END AS "PriceCareGroup",
--DIM 3
"S"."AgeGroup",
CASE
	WHEN "S"."AgeGroup" = 'infant' THEN CASE
											WHEN "CEO"."CapacityInfant" BETWEEN 1 AND 63 THEN 'from 1 to 63'
											WHEN "CEO"."CapacityInfant" BETWEEN 1 AND 63 THEN 'from 64 to 80'
											WHEN "CEO"."CapacityInfant" BETWEEN 1 AND 63 THEN 'from 81 to 100'
											WHEN "CEO"."CapacityInfant" BETWEEN 1 AND 63 THEN 'from 101 to 120'
										END
	WHEN "S"."AgeGroup" = 'toddler' THEN CASE 
											WHEN "CEO"."CapacityToddler" BETWEEN 1 AND 63 THEN 'from 1 to 63'
											WHEN "CEO"."CapacityToddler" BETWEEN 1 AND 63 THEN 'from 64 to 80'
											WHEN "CEO"."CapacityToddler" BETWEEN 1 AND 63 THEN 'from 81 to 100'
											WHEN "CEO"."CapacityToddler" BETWEEN 1 AND 63 THEN 'from 101 to 120'
										END
	WHEN "S"."AgeGroup" = 'preschooler' THEN CASE 
											WHEN "CEO"."CapacityPreschooler" BETWEEN 1 AND 63 THEN 'from 1 to 63'
											WHEN "CEO"."CapacityPreschooler" BETWEEN 1 AND 63 THEN 'from 64 to 80'
											WHEN "CEO"."CapacityPreschooler" BETWEEN 1 AND 63 THEN 'from 81 to 100'
											WHEN "CEO"."CapacityPreschooler" BETWEEN 1 AND 63 THEN 'from 101 to 120'
										END
END AS "CapacityRange",
CASE
	WHEN "S"."AgeGroup" = 'infant' AND "S"."SpecialNeeds" = 0 THEN CASE 
											WHEN "CEO"."PriceInfant" BETWEEN 200 AND 400 THEN 'from 200 to 400'
											WHEN "CEO"."PriceInfant" BETWEEN 401 AND 600 THEN 'from 401 to 600'
											WHEN "CEO"."PriceInfant" BETWEEN 601 AND 800 THEN 'from 601 to 800'
											WHEN "CEO"."PriceInfant" BETWEEN 801 AND 1000  THEN 'from 801 to 1000'
										END
	WHEN "S"."AgeGroup" = 'toddler' AND "S"."SpecialNeeds" = 0 THEN CASE
											WHEN "CEO"."PriceToddler" BETWEEN 200 AND 400 THEN 'from 200 to 400'
											WHEN "CEO"."PriceToddler" BETWEEN 401 AND 600 THEN 'from 401 to 600'
											WHEN "CEO"."PriceToddler" BETWEEN 601 AND 800 THEN 'from 601 to 800'
											WHEN "CEO"."PriceToddler" BETWEEN 801 AND 1000  THEN 'from 801 to 1000'
										END
	WHEN "S"."AgeGroup" = 'preschooler' AND "S"."SpecialNeeds" = 0 THEN CASE
											WHEN "CEO"."PricePreschooler" BETWEEN 200 AND 400 THEN 'from 200 to 400'
											WHEN "CEO"."PricePreschooler" BETWEEN 401 AND 600 THEN 'from 401 to 600'
											WHEN "CEO"."PricePreschooler" BETWEEN 601 AND 800 THEN 'from 601 to 800'
											WHEN "CEO"."PricePreschooler" BETWEEN 801 AND 1000  THEN 'from 801 to 1000'
										END
	WHEN "S"."SpecialNeeds" = 1 THEN CASE
											WHEN "CEO"."PriceSpecialNeeds" BETWEEN 200 AND 400 THEN 'from 200 to 400'
											WHEN "CEO"."PriceSpecialNeeds" BETWEEN 401 AND 600 THEN 'from 401 to 600'
											WHEN "CEO"."PriceSpecialNeeds" BETWEEN 601 AND 800 THEN 'from 601 to 800'
											WHEN "CEO"."PriceSpecialNeeds" BETWEEN 801 AND 1000  THEN 'from 801 to 1000'
										END
END AS "PriceAgeRange",
--DIM 4
"S"."Year",
--DIM 5
"S"."Status",
CASE
	WHEN "S"."SpecialNeeds" = 0 THEN 'notspecialneeds'
	WHEN "S"."SpecialNeeds" = 1 THEN 'special'
END AS "SpecialNeeds",
--DIM 6 FORBIDDEN
--MEASURES
"C"."Price" AS "PriceCare",
CASE
	WHEN "S"."AgeGroup" = 'infant' AND "S"."SpecialNeeds" = 0 THEN "CEO"."PriceInfant"
	WHEN "S"."AgeGroup" = 'toddler' AND "S"."SpecialNeeds" = 0 THEN "CEO"."PriceToddler"
	WHEN "S"."AgeGroup" = 'preschooler' AND "S"."SpecialNeeds" = 0 THEN "CEO"."PricePreschooler"
	WHEN "S"."SpecialNeeds" = 1 THEN "CEO"."PriceSpecialNeeds"
END AS "PriceAge",
------------
--DIM 1
"E"."KindergartenID", 
"E"."City", 
"E"."Name" AS "District",
CASE 
	WHEN "E"."TeachersNumber" BETWEEN 10 AND 12 THEN 'from 10 to 12'
	WHEN "E"."TeachersNumber" BETWEEN 13 AND 14 THEN 'from 13 to 14'
	WHEN "E"."TeachersNumber" BETWEEN 15 AND 17 THEN 'from 15 to 17'
END AS "NumberOfTeachers", 
CASE 
	WHEN "E"."AdditionalStaffNumber" BETWEEN 1 AND 4  THEN 'from 1 to 4'
	WHEN "E"."AdditionalStaffNumber" BETWEEN 5 AND 8 THEN 'from 5 to 8'
	WHEN "E"."AdditionalStaffNumber" BETWEEN 9 AND 12 THEN 'from 9 to 12'
	WHEN "E"."AdditionalStaffNumber" BETWEEN 13 AND 15 THEN 'from 13 to 15'
END AS "NumberOfAdditionalEmployees", 
CASE 
	WHEN "E"."TeachersNumber" + "E"."AdditionalStaffNumber" BETWEEN 11 AND 17  THEN 'from 11 to 17'
	WHEN "E"."TeachersNumber" + "E"."AdditionalStaffNumber" BETWEEN 18 AND 25 THEN 'from 18 to 25'
	WHEN "E"."TeachersNumber" + "E"."AdditionalStaffNumber" BETWEEN 26 AND 32 THEN 'from 25 to 32'
END AS "TotalNumberOfEmployees",
CASE
	WHEN "E"."FacilityNumber" BETWEEN 0 AND 4 THEN 'from 0 to 4'
	WHEN "E"."FacilityNumber" BETWEEN 5 AND 9 THEN 'from 5 to 9'
	WHEN "E"."FacilityNumber" BETWEEN 10 AND 15 THEN 'from 10 to 15'
END AS "NumberOfFacilities",
CASE 
	WHEN "E"."SpecialNeedsAvailable" = 1  THEN 'HandlesSpecialNeeds'
	WHEN "E"."SpecialNeedsAvailable" = 0 THEN 'DoesNotHandleSpecialNeeds'
END AS "HandlesSpecialNeeds"
----------
FROM 
"Kindergarten"."dbo"."Submission" AS "S",
"Kindergarten"."dbo"."KindergartenExt" AS "E",
"Kindergarten"."dbo"."KindergartenCareType" AS "C",
"Kindergarten"."dbo"."CareType" AS "CT",
"Kindergarten"."dbo"."CEO" AS "CEO"
WHERE "C"."KindergartenCareTypeID" = "S"."KindergartenCareTypeID"
AND "C"."KindergartenID" = "E"."KindergartenID"
AND "CEO"."KindergartenID" = "E"."KindergartenID"
AND "C"."CareTypeID" = "CT"."CareTypeID"



--1
USE "Kindergarten"
GO

--2
DROP VIEW IF EXISTS "Facts";

--4
SELECT TOP 200 * FROM "Facts";