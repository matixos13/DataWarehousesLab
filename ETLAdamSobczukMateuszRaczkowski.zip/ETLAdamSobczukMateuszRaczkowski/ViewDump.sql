CREATE VIEW temp AS 
SELECT DISTINCT [Status],[SpecialNeeds],
CASE 
	WHEN SpecialNeeds = 1 THEN 'special'
	WHEN SpecialNeeds = 0 THEN 'notspecialneeds'
END as sp
FROM [Kindergarten].[dbo].[Submission]