SELECT DISTINCT [Year]
      FROM [Kindergarten].[dbo].[Submission]
	  ORDER BY [Year];
USE Kernel
GO

INSERT INTO DimYear (Year)
SELECT DISTINCT [Year]
      FROM [Kindergarten].[dbo].[Submission]
	  ORDER BY [Year];

INSERT INTO DimMiscelaneous (Status, SpecialNeeds)
select [Status], [sp] from temp;

INSERT INTO DimMiscelaneous (Status, SpecialNeeds)
VALUES
('pending', 'special')

